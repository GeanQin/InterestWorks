#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <FS.h>
#include <LittleFS.h>
#include <time.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

#include "common.h"

static uint8_t macAddr[6] = {0};
static bool is_bind = false;
static char token[192] = {0};
static char ip[16] = {0};
static unsigned int did = 0;
static int weather_wait_times = 0;
static int dht_wait_times = 0;
static weather_code_e weather_code = weather_none;
static String humidity = "0.00 %";
static String temperature = "0.00 C";

WiFiServer server(80); // 创建服务器
Adafruit_SSD1306 display = Adafruit_SSD1306(128, 64, &Wire); // 定义OLED屏幕的分辨率
DHT dht(DHTPIN, DHTTYPE);                                    // 温湿度计初始化

#if 1 // little_fs
/**
 * @description: write content to file
 * @param {char} *path (file path)
 * @param {char} *content (content need to write)
 * @return {int} 0: success, -1: failed
 */
int writeFile(const char *path, const char *content)
{
    int ret = 0;
    Serial.printf("Writing to file: %s", path);
    Serial.println();

    File file = LittleFS.open(path, "w");
    if (!file)
    {
        Serial.println("Failed to open file for writing");
        return -1;
    }
    if (file.print(content))
    {
        Serial.println("File written");
    }
    else
    {
        Serial.println("Write failed");
        ret = -1;
    }
    delay(2000); // Make sure the CREATE and LASTWRITE times are different
    file.close();
    return ret;
}

/**
 * @description: append content to file
 * @param {char} *path  (file path)
 * @param {char} *content (content need to append)
 * @return {int} 0: success, -1: failed
 */
int appendFile(const char *path, const char *content)
{
    int ret = 0;

    Serial.printf("Appending to file: %s", path);
    Serial.println();

    File file = LittleFS.open(path, "a");
    if (!file)
    {
        Serial.println("Failed to open file for appending");
        return -1;
    }

    if (file.print(content))
    {
        Serial.println("File appended");
    }
    else
    {
        Serial.println("Append failed");
        ret = -1;
    }

    file.close();

    return ret;
}

/**
 * @description: delete file
 * @param {char} *path  (file path)
 * @return {int} 0: success, -1: failed
 */
int deleteFile(const char *path)
{
    Serial.printf("Deleting file: %s", path);
    Serial.println();

    if (LittleFS.remove(path))
    {
        Serial.println("File deleted");
        return 0;
    }
    else
    {
        Serial.println("Delete failed");
        return -1;
    }
}

/**
 * @description: read content from file
 * @param {char} *path  (file path)
 * @param {String} *content (content have read)
 * @return {int}  0: success, -1: failed
 */
int readFile(const char *path, String *content)
{
    Serial.printf("Reading file: %s", path);
    Serial.println();

    File file = LittleFS.open(path, "r");
    if (!file)
    {
        Serial.println("Failed to open file for reading");
        return -1;
    }

    while (file.available())
    {
        char tmp = file.read();
        *content += tmp;
    }
    file.close();

    if (content->length() <= 0)
    {
        return -1;
    }

    return 0;
}

/**
 * @description: check file if exist
 * @param {char} *path  (file path)
 * @return {int} 0: exist, -1: do not exist
 */
int checkFile(const char *path)
{
    Dir root = LittleFS.openDir("/");
    while (root.next())
    {
        // Serial.println(root.fileName());
        if (strncmp(root.fileName().c_str(), path, strlen(path)) == 0)
        {
            return 0;
        }
    }
    return -1;
}
#endif // little_fs

#if 1 // http post\get
void http_post(const String url, const String data, String *ret_str)
{
    // 创建 WiFiClient 实例化对象
    WiFiClient wifi_client;
    // 创建http对象
    HTTPClient http_client;

    // 配置请求地址
    Serial.print("POST url: ");
    Serial.println(url.c_str());
    http_client.begin(wifi_client, url); // HTTP请求
    http_client.addHeader("Content-Type", "application/x-www-form-urlencoded");

    // 启动连接并发送HTTP报头和报文
    Serial.print("POST data: ");
    Serial.println(data.c_str());
    int httpCode = http_client.POST(data);

    // 连接失败时 httpCode时为负
    if (httpCode > 0)
    {
        // 将从服务器获取的数据打印到串口
        if (httpCode == HTTP_CODE_OK)
        {
            *ret_str = http_client.getString();
            Serial.print("POST ret: ");
            Serial.println(ret_str->c_str());
        }
    }
    else
    {
        Serial.print("URL POST ERR: ");
        Serial.println(httpCode);
    }
    // 关闭http连接
    wifi_client.stop();
    http_client.end();
}

void http_get(const char *url, String *ret_str)
{
    HTTPClient http_client;
    WiFiClient wifi_client;

    http_client.begin(wifi_client, String(url));
    Serial.print("URL: ");
    Serial.println(url);

    // 启动连接并发送HTTP请求
    int http_code = http_client.GET();
    if (http_code == HTTP_CODE_OK)
    {
        *ret_str = http_client.getString();
        Serial.print("URL GET: ");
        Serial.println(ret_str->c_str());
    }
    else
    {
        Serial.print("URL GET ERR: ");
        Serial.println(http_code);
    }

    wifi_client.stop();
    http_client.end();
}
#endif // http post\get

bool get_local_time(struct tm *info, uint32_t ms)
{
    uint32_t count = ms / 10;
    time_t now;

    time(&now);
    localtime_r(&now, info);

    if (info->tm_year > (2016 - 1900))
    {
        return true;
    }

    while (count--)
    {
        delay(10);
        time(&now);
        localtime_r(&now, info);
        if (info->tm_year > (2016 - 1900))
        {
            return true;
        }
    }
    return false;
}

// Get: GET /bind?ssid=1&psk=2&email=3&password=4&name=5&position=6 HTTP/1.1
void find_value_by_key(const char *str, String key, char *value)
{
    size_t i = 0;
    char *val_p = strstr(str, key.c_str()) + key.length() + 1;
    for (i = 0; i < strlen(val_p); i++)
    {
        if (val_p[i] == '&' || val_p[i] == ' ')
        {
            if (i < BIND_INFO_LEN_MAX)
            {
                memcpy(value, val_p, i);
            }
            else
            {
                memcpy(value, val_p, BIND_INFO_LEN_MAX);

            }
            break;
        }
    }
}

void rebind()
{
    LittleFS.format();
    ESP.reset();
}

void find_ip()
{
    String tmp = "";
    while (tmp.length() == 0)
    {
        delay(1000);
        http_get(IP_URL, &tmp);
    }
    memcpy(ip, tmp.c_str(), tmp.length() + 1);
}

void connect_wifi(char *ssid, char *psk)
{
    Serial.printf("ssid: %s, psk: %s", ssid, psk);
    Serial.println();
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, psk);
    display.setTextSize(1);  // 设置字体大小2 高12
    display.setCursor(0, 0); // 设置开始显示文字的坐标
    display.println("Connectting WiFi");
    display.display();

    int wait_count = 0;
    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        wait_count += 1;
        Serial.print(".");
        display.print(".");
        display.display();
        if (wait_count > 60)
        {
            rebind();
        }
    }
    Serial.println("WiFi connected");
    Serial.println("NAT IP address: ");
    Serial.println(WiFi.localIP());

    find_ip();
    Serial.println("PUB IP address: ");
    Serial.println(ip);

    Serial.println("Contact Time Server");
    configTime(3600 * LOCAL_TZ, DAY_LIGHT_OFFSET, "time.nist.gov", "0.pool.ntp.org", "1.pool.ntp.org"); // 配置时间服务器
}

void cloud_login(char *email, char *password)
{
    String data = String("email=") + email + String("&password=") + password;
    String ret = "";
    http_post(LOGIN_URL, data, &ret);
    JsonDocument json_root;
    if (deserializeJson(json_root, ret))
    {
        Serial.println("deserialize json err");
        rebind();
    }
    if (strcmp(json_root["msg"], "Success.") == 0)
    {
        strcpy(token, json_root["data"]["token"]);
        Serial.println(token);
    }
    else
    {
        rebind();
    }
}

void cloud_bind(char *name, char *position)
{
    String data = String("table=") + DATABASE_NAME + String("&name=") + name + String("&position=") + position + String("&token=") + token;
    String ret = "";
    http_post(BIND_URL, data, &ret);
    JsonDocument json_root;
    if (deserializeJson(json_root, ret))
    {
        Serial.println("deserialize json err");
        rebind();
    }
    if (strcmp(json_root["msg"], "Success.") == 0)
    {
        did = json_root["data"]["did"];
        Serial.println(did);
    }
    else
    {
        rebind();
    }
}

void cloud_unbind()
{
    String data = String("table=") + DATABASE_NAME + String("&did=") + String(did) + String("&token=") + token;
    String ret = "";
    http_post(UNBIND_URL, data, &ret);
}

weather_code_e cloud_weather()
{
    weather_code_e code = weather_none;
    String data = String("ip=") + ip + String("&token=") + token;
    String ret = "";
    http_post(WEATHER_URL, data, &ret);
    JsonDocument json_root;
    if (deserializeJson(json_root, ret))
    {
        Serial.println("deserialize json err");
        return code;
    }
    if (strcmp(json_root["msg"], "Success.") == 0)
    {
        const char *weather = json_root["data"]["weather"];
        Serial.println(weather);
        if (strstr(weather, "晴") != NULL || strstr(weather, "云") != NULL)
        {
            return weather_sun;
        }
        else if (strstr(weather, "风") != NULL || strstr(weather, "沙") != NULL)
        {
            return weather_wind;
        }
        else if (strstr(weather, "霾") != NULL)
        {
            return weather_haze;
        }
        else if (strstr(weather, "雨") != NULL)
        {
            return weather_rain;
        }
        else if (strstr(weather, "雪") != NULL)
        {
            return weather_snow;
        }
        else if (strstr(weather, "雾") != NULL)
        {
            return weather_fog;
        }
        else
        {
            return weather_cloudy;
        }
    }
    else
    {
        Serial.println("get weather err");
        return code;
    }

    return code;
}

void setup()
{
    Serial.begin(115200);
    WiFi.macAddress(macAddr);
    pinMode(UNBIND_BUTTON_NUM, INPUT);
    display.begin(SSD1306_SWITCHCAPVCC, 0x3C); // 设置OLED的I2C地址
    display.setTextColor(SSD1306_WHITE);       // 设置字体颜色
    display.clearDisplay();

    if (!LittleFS.begin())
    {
        Serial.println("LittleFS mount failed");
        rebind();
    }
    else
    {
        Serial.println("Mount LittleFS");
        if (checkFile(BIND_INFO_FILE) == 0)
        {
            String cnt_str = "";
            if (readFile(BIND_INFO_FILE, &cnt_str))
            {
                Serial.println("Get bind info from file failed");
                rebind();
            }
            Serial.println(cnt_str.c_str());

            // 联网
            char ssid[BIND_INFO_LEN_MAX] = {0};
            char psk[BIND_INFO_LEN_MAX] = {0};
            find_value_by_key(cnt_str.c_str(), "ssid", ssid);
            find_value_by_key(cnt_str.c_str(), "psk", psk);
            connect_wifi(ssid, psk);

            // 登录
            char email[BIND_INFO_LEN_MAX] = {0};
            char password[BIND_INFO_LEN_MAX] = {0};
            find_value_by_key(cnt_str.c_str(), "email", email);
            find_value_by_key(cnt_str.c_str(), "password", password);
            cloud_login(email, password);

            char did_str[16] = {0};
            find_value_by_key(cnt_str.c_str(), "did", did_str);
            did = String(did_str).toInt();

            is_bind = true;
            dht.begin(); // 开启温湿度计
        }
    }

    if (!is_bind)
    {
        if (checkFile(CONNECT_INFO_FILE) == 0)
        {
            String cnt_str = "";
            if (readFile(CONNECT_INFO_FILE, &cnt_str))
            {
                Serial.println("Get connect info from file failed");
                rebind();
            }
            Serial.println(cnt_str.c_str());

            // 联网
            char ssid[BIND_INFO_LEN_MAX] = {0};
            char psk[BIND_INFO_LEN_MAX] = {0};
            find_value_by_key(cnt_str.c_str(), "ssid", ssid);
            find_value_by_key(cnt_str.c_str(), "psk", psk);
            connect_wifi(ssid, psk);

            // 登录
            char email[BIND_INFO_LEN_MAX] = {0};
            char password[BIND_INFO_LEN_MAX] = {0};
            find_value_by_key(cnt_str.c_str(), "email", email);
            find_value_by_key(cnt_str.c_str(), "password", password);
            cloud_login(email, password);

            // 绑定
            char name[BIND_INFO_LEN_MAX] = {0};
            char position[BIND_INFO_LEN_MAX] = {0};
            find_value_by_key(cnt_str.c_str(), "name", name);
            find_value_by_key(cnt_str.c_str(), "position", position);
            cloud_bind(name, position);

            // 保存绑定信息
            String bind_info = String("did=") + String(did) +
                               String("&ssid=") + ssid + String("&psk=") + psk +
                               String("&email=") + email + String("&password=") + password +
                               String("&name=") + name + String("&position=") + position;
            writeFile(BIND_INFO_FILE, bind_info.c_str());

            display.setTextSize(1);  // 设置字体大小2 高12
            display.setCursor(0, 0); // 设置开始显示文字的坐标
            display.println("Bind success.");
            display.display();

            deleteFile(CONNECT_INFO_FILE);
            is_bind = true;
            dht.begin(); // 开启温湿度计
        }
        else
        {
            char ssid[32] = {0};
            snprintf(ssid, sizeof(ssid), "%s_%02x%02x%02x", PROJECT_NAME, macAddr[3], macAddr[4], macAddr[5]);
            WiFi.mode(WIFI_AP);
            WiFi.softAP(ssid); // 建立热点
            server.begin();    // 开启服务器

            Serial.println("Start AP mode");
            display.setTextSize(1);  // 设置字体大小2 高12
            display.setCursor(0, 0); // 设置开始显示文字的坐标
            display.println("Connect WiFi:");
            display.println(ssid);
            display.println("");
            display.println("And access the addr:");
            display.println("192.168.4.1");
            display.display();
        }
    }
}

void loop()
{
    int unbind_flag = digitalRead(UNBIND_BUTTON_NUM);
    if (unbind_flag == 0)
    {
        Serial.println("unbind and reset");
        if (is_bind)
        {
            cloud_unbind();
        }
        rebind();
    }

    if (!is_bind)
    {
        WiFiClient client = server.accept(); // 获取客户端对象
        if (!client)
        {
            return;
        }
        while (!client.available()) // 等待客户端连接
        {
            delay(100);
        }
        client.print("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"); // 收到请求回复200
        String request_str = client.readStringUntil('\r');                  // 读取客户端发来的请求
        Serial.printf("Get: %s", request_str.c_str());
        Serial.println();

        char *para = strstr(request_str.c_str(), REQ_BIND);
        if (para != NULL)
        {
            client.print("<h1>wait connect...</h1>");
            display.clearDisplay();
            display.setTextSize(1);  // 设置字体大小2 高12
            display.setCursor(0, 0); // 设置开始显示文字的坐标
            display.println("Get bind info.");
            display.println("");
            display.println("Please wait.");
            display.display();
            delay(1000);
            writeFile(CONNECT_INFO_FILE, para + strlen(REQ_BIND));
            ESP.reset();
        }
        else
        {
            client.print(BIND_WEB);
        }
    }
    else
    {
        display.clearDisplay();

        // 获取时间
        struct tm tmstruct;
        tmstruct.tm_year = 0;
        get_local_time(&tmstruct, 5000);

        char hms[32] = {0};
        snprintf(hms, 32, "%02d:%02d:%02d", tmstruct.tm_hour, tmstruct.tm_min, tmstruct.tm_sec);

        char md[32] = {0};
        snprintf(md, 32, "%02d/%02d", (tmstruct.tm_mon) + 1, tmstruct.tm_mday);

        Serial.print(hms);
        Serial.print(" ");
        Serial.println(md);

        display.setTextSize(2);   // 设置字体大小2 高12
        display.setCursor(32, 0); // 设置开始显示文字的坐标
        display.println(hms);

        display.setTextSize(1);    // 设置字体大小1 高6
        display.setCursor(96, 16); // 设置开始显示文字的坐标
        display.println(md);

        // 天气
        if (weather_wait_times == 0)
        {
            weather_code = cloud_weather();
        }
        weather_wait_times += 1;
        if (weather_wait_times > WEATHER_WAIT)
        {
            weather_wait_times = 0;
        }
        switch (weather_code)
        {
        case weather_sun:
            display.drawBitmap(8, 32, sun_48_32_h, 48, 32, WHITE);
            break;

        case weather_wind:
            display.drawBitmap(8, 32, wind_48_32_h, 48, 32, WHITE);
            break;

        case weather_snow:       
        case weather_rain:
            display.drawBitmap(8, 32, rain_48_32_h, 48, 32, WHITE);
            break;

        case weather_fog:
            display.drawBitmap(8, 32, fog_48_32_h, 48, 32, WHITE);
            break;
        
        default:
            display.drawBitmap(8, 32, cloud_48_32_h, 48, 32, WHITE);
            break;
        }

        // 获取温湿度
        if (dht_wait_times == 0)
        {
            float h = dht.readHumidity();    // 湿度
            float t = dht.readTemperature(); // 温度
            if (isnan(h) || isnan(t))
            {
                Serial.println(F("Failed to read from DHT sensor!"));
                humidity = "0.00 %";
                temperature = "0.00 C";
            }
            else
            {
                temperature = String(t - 2);
                temperature += " C";
                Serial.println(temperature);
                humidity = String(h + 4);
                humidity += " %";
                Serial.println(humidity);
            }
        }
        dht_wait_times += 1;
        if (dht_wait_times > DHT_WAIT)
        {
            dht_wait_times = 0;
        }

        display.setTextSize(1);    // 设置字体大小
        display.setCursor(64, 40); // 设置开始显示文字的坐标
        display.println(temperature);

        display.setTextSize(1);    // 设置字体大小
        display.setCursor(64, 48); // 设置开始显示文字的坐标
        display.println(humidity); // 输出的字符

        display.display(); // 使更改的显示生效
        delay(600);
    }
}